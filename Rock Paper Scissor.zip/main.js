let win = 0;
let draw = 0;
let lose = 0;
document.getElementById("win").innerHTML = win;
document.getElementById("draw").innerHTML = draw;
document.getElementById("lose").innerHTML = lose;
document.getElementById("myHandImg").src = "img/gameIcon.png";
document.getElementById("yourHandImg").src = "img/gameIcon.png";

function randomMyHand(){
    let mine = Math.random();
    let myHand,myHandP;
    if (mine < 1 / 3.0) {
        myHand = "BATU";
    } else if (mine > 2 / 3.0) {
        myHand = "KERTAS";
    } else {
        myHand = "GUNTING";
    }
    document.getElementById("myHandImg").src = "img/" + myHand.toLowerCase() + ".png";
    document.getElementById("myHandP").innerHTML = myHand;
    return myHand;
}

function submitForm(event, x) {
    event.preventDefault(); // Mencegah pengiriman formulir secara langsung
    let myHand = randomMyHand();
    let button;

    if (x == 1) {
        button = document.querySelector("#batu");
    } else if (x == 2) {
        button = document.querySelector("#gunting");
    } else {
        button = document.querySelector("#kertas");
    }
    
    var yourHand = button.value.toUpperCase();
    document.getElementById("yourHandImg").src = "img/" + yourHand.toLowerCase() + ".png";
    document.getElementById("yourHandP").innerHTML = yourHand;
    
    let result;
    if (myHand == "BATU") {
        if (yourHand == "BATU") {
            result = "DRAW";
            draw += 1;
        } else if (yourHand == "KERTAS") {
            result = "YOU WIN";
            win += 1;
        } else {
            result = "YOU LOSE";
            lose += 1;
        }
    } else if (myHand == "KERTAS") {
        if (yourHand == "BATU") {
            result = "YOU LOSE";
            lose += 1;
        } else if (yourHand == "KERTAS") {
            result = "DRAW";
            draw += 1;
        } else {
            result = "YOU WIN";
            win += 1;
        }
    } else {
        if (yourHand == "BATU") {
            result = "YOU WIN";
            win += 1;
        } else if (yourHand == "KERTAS") {
            result = "YOU LOSE";
            lose += 1;
        } else {
            result = "DRAW";
            draw += 1;
        }
    }
    document.getElementById("gameResult").innerHTML = result;
    document.getElementById("win").innerHTML = win;
    document.getElementById("draw").innerHTML = draw;
    document.getElementById("lose").innerHTML = lose;
}