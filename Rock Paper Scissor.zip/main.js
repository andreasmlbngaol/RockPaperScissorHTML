function submitForm(event, x) {
    event.preventDefault(); // Mencegah pengiriman formulir secara langsung

    let mine = Math.random();
    let myHand;
    if (mine < 1 / 3.0) {
        myHand = "BATU";
    } else if (mine > 2 / 3.0) {
        myHand = "KERTAS";
    } else {
        myHand = "GUNTING";
    }

    let button;

    if (x == 1) {
        button = document.querySelector("#batu");
    } else if (x == 2) {
        button = document.querySelector("#gunting");
    } else {
        button = document.querySelector("#kertas");
    }

    var selectedOption = button.value;
    let result;

    var yourHand = selectedOption.value.toUpperCase();
    document.getElementById("yourHand").innerHTML = yourHand;
    document.getElementById("myHand").innerHTML = myHand;

    if (myHand == "BATU") {
        if (yourHand == "BATU") {
            result = "DRAW";
        } else if (yourHand == "KERTAS") {
            result = "YOU WIN";
        } else {
            result = "YOU LOSE";
        }
    } else if (myHand == "KERTAS") {
        if (yourHand == "BATU") {
            result = "YOU LOSE";
        } else if (yourHand == "KERTAS") {
            result = "DRAW";
        } else {
            result = "YOU WIN";
        }
    } else {
        if (yourHand == "BATU") {
            result = "YOU WIN";
        } else if (yourHand == "KERTAS") {
            result = "YOU LOSE";
        } else {
            result = "DRAW";
        }
    }
    document.getElementById("gameResult").innerHTML = result;
}